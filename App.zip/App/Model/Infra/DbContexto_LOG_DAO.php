<?php

/**
 * Description of DbContexto_LOG_DAO
 *
 * @author paulo-pc
 */
class DbContexto_LOG_DAO extends DbContextoDAO
{
   public function GatilhoLog()
   {
       //logs
   }    
}
