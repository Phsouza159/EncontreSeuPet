<?php
 //include './Post.php';
/**
 * Description of PerdidoPOST
 *
 * @author paulo-pc
 */
final class PerdidoPOST extends Post{

    
    
}
