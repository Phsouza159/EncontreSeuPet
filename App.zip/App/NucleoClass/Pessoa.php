<?php
/**
 * Description of Pessoa
 *
 * @author paulo-pc
 */
class Pessoa {
    private $nome;
    
    public function getNome() {
        return $this->nome;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

 
    
}
