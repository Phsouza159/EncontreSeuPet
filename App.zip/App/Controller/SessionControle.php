<?php

Class SessionControle
{
        
}
